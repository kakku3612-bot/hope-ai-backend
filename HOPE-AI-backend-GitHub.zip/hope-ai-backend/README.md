# HOPE AI Backend

Spring Boot backend for HOPE AI.

## Required environment variables

- `OPENAI_API_KEY` — your OpenAI API key
- `OPENAI_MODEL` — default: `gpt-5.6-luna`
- `OPENAI_BASE_URL` — default: `https://api.openai.com/v1`

The API key must stay on the server. Do not put it in the Android app, website JavaScript, GitHub repository, or APK.

## Local run

```bash
mvn spring-boot:run
```

## Chat endpoint

`POST /api/chat`

Request:
```json
{"message":"Hello HOPE AI"}
```

Response:
```json
{"reply":"Hello! How can I help?"}
```

## Health endpoint

`GET /api/health`
