package com.hopeai.app;

public record ChatResponse(String reply) {}
