package com.hopeai.app;

public record ChatRequest(String message) {}
