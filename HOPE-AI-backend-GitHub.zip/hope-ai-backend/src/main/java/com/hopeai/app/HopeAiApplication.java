package com.hopeai.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HopeAiApplication {
    public static void main(String[] args) {
        SpringApplication.run(HopeAiApplication.class, args);
    }
}
