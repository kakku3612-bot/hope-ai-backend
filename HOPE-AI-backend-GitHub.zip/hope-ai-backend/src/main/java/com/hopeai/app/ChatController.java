package com.hopeai.app;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class ChatController {

    private final OpenAiService openAiService;

    public ChatController(OpenAiService openAiService) {
        this.openAiService = openAiService;
    }

    @GetMapping("/health")
    public ResponseEntity<String> health() {
        return ResponseEntity.ok("HOPE AI backend is running");
    }

    @PostMapping("/chat")
    public ResponseEntity<ChatResponse> chat(@RequestBody ChatRequest request) {
        if (request == null || request.message() == null || request.message().isBlank()) {
            return ResponseEntity.badRequest().body(new ChatResponse("Please enter a message."));
        }

        try {
            return ResponseEntity.ok(new ChatResponse(openAiService.reply(request.message().trim())));
        } catch (Exception e) {
            return ResponseEntity.internalServerError()
                    .body(new ChatResponse("HOPE AI could not reach the AI service right now."));
        }
    }
}
